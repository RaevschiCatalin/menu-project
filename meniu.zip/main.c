#include <ncurses.h>
#include <stdlib.h>

int highlight = 1;
int choice = 0;
int c;
char *menu_items[] = {
        "  Adauga un event",
        "  Sterge un event",
        "  Vizualizarea evenimentelor",
        "  Iesi"
    };


int menu_size = sizeof(menu_items) / sizeof(menu_items[0]);


void main_menu(int hi){
        clear();
        printw("============Meniul Principal============\n");
        printw("== Utilizati sagetile pentru navigare ==\n");
        printw("========================================\n\n");
        for (int i = 0; i < menu_size; i++) {
            if (i + 1 == hi) {
                attron(A_REVERSE);//highlight la alegere
            }
            printw("%s\n",menu_items[i]);
            attroff(A_REVERSE);//hz
        }
        return;
}
int choose(){

    while (1) {
        main_menu(highlight);
        c = getch();
        switch(c) {
            case 'w':
            case KEY_UP:
                if (highlight > 1)
                    highlight--;
                break;
            case 's':
            case KEY_DOWN:
                if (highlight < menu_size)
                    highlight++;
                    choice++;
                break;
            case 'd':
            case KEY_RIGHT:
                if (highlight < menu_size)
                    highlight++;
                break;
            case 'a':
            case KEY_LEFT:
                if (highlight > 1)
                    highlight--;
                break;
             case '\n':
            case KEY_ENTER:
                choice = highlight;

                return choice;
        }
    }
    return 0;
}

void add_meeting(){
    clear();
    echo();
    char str[10];
    mvprintw(1,15,"================================================\n");
    mvprintw(2,15,"=== Introdu data, ora si denumirea eventului ===\n");
    mvprintw(3,15,">>> ");
    int j = getch();
    while(j != KEY_ENTER){
        getstr(str);
        break;
    }
    mvprintw(6,15," Apasa Backspace pentru a reveni la Meniul Principal");
    int c = getch();
    if(c == KEY_BACKSPACE)
        choose();

    return;

}

void delete_meeting(){
    clear();
    echo();
    char str[80];
    mvprintw(1,15,"================================================\n");
    mvprintw(2,15,"============== Ce vrei sa stergi? ==============\n");
    mvprintw(3,15,">>>");
    int j = getch();
    while(j != KEY_ENTER){
        getstr(str);
        break;
    }
    mvprintw(6,15," Apasa Backspace pentru a reveni la Meniul Principal");
    int c = getch();
    if(c == KEY_BACKSPACE)
        choose();
    return;
}

void view(){
    clear();
    echo();
    char str[80];
    mvprintw(1,15,"================================================\n");
    mvprintw(2,15,"==============In curs de dezvoltare... =========\n");
    int j = getch();
    while(j != KEY_ENTER){
        getstr(str);
        break;
    }
    mvprintw(6,15," Apasa Backspace pentru a reveni la Meniul Principal");
    int c = getch();
    if(c == KEY_BACKSPACE)
        choose();

    return;


}
int main() {
    initscr();
    cbreak();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    int aleg = choose();
    while (aleg != 0) {
        switch(aleg) {
            case 1:
                add_meeting();
                break;
            case 2:
                delete_meeting();
                break;
            case 3:
                view();
                break;
            case 4:
                endwin();
                exit(0);
            default:
                break;
        }
        aleg = choose();
    }


    return 0;
}

